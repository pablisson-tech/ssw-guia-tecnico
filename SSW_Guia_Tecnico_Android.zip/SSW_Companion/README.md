# SSW Guia Técnico — projeto Android

Aplicativo de consulta em português para WEG SSW-07/SSW-08, baseado no Manual de Programação 0899.5530/08, software V1.5X. O conteúdo inclui catálogo de parâmetros, busca por categoria, diagnóstico de falhas, guia da HMI, guias de configuração e links para documentação do fabricante.

## Conteúdo entregue
- `app/src/main/assets/index.html`: interface responsiva e offline.
- `parameters.json`: parâmetros e descrições resumidas do manual. Faixas contínuas são agrupadas quando são uma família de parâmetros.
- `errors.json`: erros e orientações de triagem para E03, E04, E05, E06, E10, E19, E24, E28, E31, E62, E63, E66, E67, E70, E71, E72, E74, E75, E76 e E77.
- `manifest.json` e `sw.js`: suporte PWA/cache offline em hospedagem HTTPS.
- Código Kotlin de um wrapper Android WebView que carrega os arquivos locais via `WebViewAssetLoader`.

## Gerar APK no Android Studio
1. Instale Android Studio estável com Android SDK Platform 35 e JDK 17.
2. Abra a pasta `SSW_Companion` como projeto existente.
3. Aguarde o Gradle Sync.
4. Selecione **Build > Build APK(s)**.
5. O APK de depuração normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

Este ambiente de entrega não possui Gradle/Android SDK instalados, portanto o APK não foi compilado aqui. O projeto-fonte está preparado para abrir e compilar no Android Studio.

## Usar como PWA sem Android Studio
Hospede os arquivos de `app/src/main/assets/` em um site HTTPS. Abra no Chrome Android e escolha **Adicionar à tela inicial/Instalar app**. Após o primeiro carregamento, o cache permite consultas offline.

## Fontes
- WEG, Manual de Programação SSW-07/SSW-08, V1.5X: https://static.weg.net/medias/downloadcenter/h08/hd9/WEG-ssw07-manual-de-programacao-0899.5530-1.5x-manual-portugues-br.pdf
- WEG, Manual do Usuário SSW-07, 2024: https://static.weg.net/medias/downloadcenter/h8f/h39/WEG-SSW07-user-manual-0899.5832-en-es-pt.pdf
- WEG, Manual de Comunicação Serial SSW-07/SSW-08: https://static.weg.net/medias/downloadcenter/h6b/h04/WEG-SSW07-SSW08-serial-communication-manual-0899.5803-en.pdf
- Referência adicional de troubleshooting: https://www.manualslib.com/manual/1720070/Weg-Ssw-07.html?page=161

## Aviso
Não é aplicativo oficial da WEG e não se conecta fisicamente à soft-starter. As sugestões de diagnóstico não substituem o manual do usuário, o manual específico do módulo, análise do circuito nem suporte técnico. Não desative proteções nem faça pontes em circuitos de segurança.

## Compilação automática pelo GitHub Actions

O projeto inclui `.github/workflows/build-apk.yml`. Depois que os arquivos forem enviados para um repositório GitHub, abra a aba **Actions**, selecione **Build Android APK** e execute **Run workflow** (ou aguarde a compilação automática após um push). Quando terminar com sucesso, abra a execução e baixe o artefato **SSW-Guia-Tecnico-APK**. Dentro do ZIP baixado estará `app-debug.apk`.
